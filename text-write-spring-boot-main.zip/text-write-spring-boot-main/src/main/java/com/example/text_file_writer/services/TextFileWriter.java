package com.example.text_file_writer.services;

import com.example.text_file_writer.model.FileData;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

public interface TextFileWriter {
    List<FileData> readAllData() throws IOException;
    FileData readSpecificData(String id) throws IOException;
    void insertData(FileData newData) throws IOException;
    void updateData(String id, String newContent) throws IOException;
    void deleteSpecificData(String id) throws IOException;
    void deleteAllData() throws IOException;
    void mergeData(String id1, String id2) throws IOException;

    void sortData(String sortBy) throws IOException;

    List<FileData> searchData(String keyword) throws IOException;

    void writeDataListToFile(List<FileData> dataList) throws IOException;
}
