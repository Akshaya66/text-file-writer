CREATE TABLE file_data (
    id INT NOT NULL AUTO_INCREMENT,
    content VARCHAR(255),
    PRIMARY KEY (id)
);
