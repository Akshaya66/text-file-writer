package com.example.text_writer_intel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TextWriterIntelApplication {

	public static void main(String[] args) {
		SpringApplication.run(TextWriterIntelApplication.class, args);
	}

}
