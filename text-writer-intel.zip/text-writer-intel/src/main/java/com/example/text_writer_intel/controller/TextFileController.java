package com.example.text_writer_intel.controller;


import com.example.text_writer_intel.model.FileData;
import com.example.text_writer_intel.services.TextFileWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/textfile")
public class TextFileController {

    @Autowired
    private TextFileWriter textFileService;

    @PostMapping("/insert")
    public ResponseEntity<String> insertData(@RequestBody FileData newData, @RequestParam("db") Boolean enabledDb) {
        try {
            textFileService.insertData(newData, enabledDb);
            return new ResponseEntity<>("Data inserted successfully", HttpStatus.OK);
        } catch (IOException e) {
            return new ResponseEntity<>("Error inserting data: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteSpecificData(@PathVariable String id, @RequestParam("db") Boolean enabledDb) {
        try {
            textFileService.deleteSpecificData(id, enabledDb);
            return new ResponseEntity<>("Data deleted successfully", HttpStatus.OK);
        } catch (IOException e) {
            return new ResponseEntity<>("Error deleting data: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/deleteAll")
    public ResponseEntity<String> deleteAllData(@RequestParam("db") Boolean enabledDb) {
        try {
            textFileService.deleteAllData(enabledDb);
            return new ResponseEntity<>("All data deleted successfully", HttpStatus.OK);
        } catch (IOException e) {
            return new ResponseEntity<>("Error deleting all data: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/readAll")
    public ResponseEntity<List<FileData>> readAllData(@RequestParam("db") Boolean enabledDb) {
        try {
            List<FileData> data = textFileService.readAllData(enabledDb);
            if (data.isEmpty()) {
                return new ResponseEntity<>(null, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(data, HttpStatus.OK);
        } catch (IOException e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/read/{id}")
    public ResponseEntity<FileData> readSpecificData(@PathVariable String id, @RequestParam("db") Boolean enabledDb) {
        try {
            FileData data = textFileService.readSpecificData(id, enabledDb);
            if (data != null) {
                return new ResponseEntity<>(data, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
            }
        } catch (IOException e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateData(@PathVariable String id, @RequestBody String newContent, @RequestParam("db") Boolean enabledDb) {
        try {
            textFileService.updateData(id, newContent, enabledDb);
            return new ResponseEntity<>("Data updated successfully", HttpStatus.OK);
        } catch (IOException e) {
            return new ResponseEntity<>("Error updating data: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/merge")
    public ResponseEntity<Void> mergeData(@RequestParam String id1, @RequestParam String id2, @RequestParam("db") Boolean enabledDb) {
        try {
            textFileService.mergeData(id1, id2, enabledDb);
            return new ResponseEntity<>(HttpStatus.OK); // HTTP 204 No Content
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/sort")
    public ResponseEntity<String> sortData(@RequestParam String sortBy, @RequestParam("db") Boolean enabledDb) {
        try {
            textFileService.sortData(sortBy, enabledDb);
            return new ResponseEntity<>("Data sorted successfully.", HttpStatus.OK);
        } catch (IOException e) {
            return new ResponseEntity<>("Error sorting data: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/search")
    public ResponseEntity<List<FileData>> searchData(@RequestParam String content, @RequestParam("db") Boolean enabledDb) {
        try {
            List<FileData> results = textFileService.searchData(content, enabledDb);
            return new ResponseEntity<>(results, HttpStatus.OK);
        } catch (IOException e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}



