package com.example.text_writer_intel.services;


import com.example.text_writer_intel.model.FileData;

import java.io.IOException;
import java.util.List;

public interface TextFileWriter {
    List<FileData> readAllData(Boolean enabledDb) throws IOException;
    FileData readSpecificData(String id, Boolean enabledDb) throws IOException;
    void insertData(FileData newData, Boolean enabledDb) throws IOException;
    void updateData(String id, String newContent, Boolean enabledDb) throws IOException;
    void deleteSpecificData(String id, Boolean enabledDb) throws IOException;
    void deleteAllData(Boolean enabledDb) throws IOException;
    void mergeData(String id1, String id2, Boolean enabledDb) throws IOException;

    void sortData(String sortBy, Boolean enabledDb) throws IOException;

    List<FileData> searchData(String keyword, Boolean enabledDb) throws IOException;

    void writeDataListToFile(List<FileData> dataList) throws IOException;
}
