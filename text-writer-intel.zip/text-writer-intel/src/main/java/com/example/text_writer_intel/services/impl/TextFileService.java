package com.example.text_writer_intel.services.impl;

import com.example.text_writer_intel.model.FileData;
import com.example.text_writer_intel.repository.TextFileRepository;
import com.example.text_writer_intel.services.TextFileWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Service
public class TextFileService implements TextFileWriter {
    private final String filePath = "src/main/resources/data.txt";

    @Autowired
    private TextFileRepository textFileRepository;

    private File getFile() {
        return new File(filePath);
    }

    @Override
    public List<FileData> readAllData(Boolean enabledDb) throws IOException {
        if (enabledDb) {
            return textFileRepository.findAll();
        } else {
            File file = getFile();
            List<FileData> dataList = new ArrayList<>();
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",", 2);
                    if (parts.length >= 2) {
                        FileData data = new FileData();
                        data.setId(parts[0]);
                        data.setContent(parts[1]);
                        dataList.add(data);
                    }
                }
            } catch (IOException e) {
                System.err.println("Error reading data from file: " + e.getMessage());
                throw e;
            }
            return dataList;
        }
    }

    @Override
    public FileData readSpecificData(String id, Boolean enabledDb) throws IOException {
        List<FileData> allData = readAllData(enabledDb);
        for (FileData data : allData) {
            if (data.getId().equals(id)) {
                return data;
            }
        }
        return null;
    }

    @Override
    public void insertData(FileData newData, Boolean enabledDb) throws IOException {
        if (newData == null) {
            throw new IllegalArgumentException("FileData cannot be null");
        }
        if (newData.getId() == null || newData.getId().trim().isEmpty()) {
            throw new IllegalArgumentException("FileData ID cannot be null or empty");
        }
        if (newData.getContent() == null) {
            throw new IllegalArgumentException("FileData content cannot be null");
        }
        if (enabledDb) {
            textFileRepository.save(newData);
        } else {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(getFile(), true))) {
                writer.write(newData.getId() + "," + newData.getContent());
                writer.newLine();
            } catch (IOException e) {
                System.err.println("Error writing data to file: " + e.getMessage());
                throw e;
            }
        }
    }

    @Override
    public void updateData(String id, String newContent, Boolean enabledDb) throws IOException {
        if (enabledDb) {
            Optional<FileData> data = textFileRepository.findById(id);
            if (data.isPresent()) {
                FileData fileData = data.get();
                fileData.setContent(newContent);
                textFileRepository.save(fileData);
            } else {
                throw new IOException("ID not found for update");
            }

        } else {
            List<FileData> allData = readAllData(false);
            List<FileData> dataList = new ArrayList<>();
            boolean found = false;
            for (FileData data : allData) {
                if (data.getId().equals(id)) {
                    data.setContent(newContent);
                    found = true;
                }
                dataList.add(data);
            }

            if (!found) {
                throw new IOException("ID not found for update");
            }
            writeDataListToFile(dataList);
        }
    }

    @Override
    public void deleteSpecificData(String id, Boolean enabledDb) throws IOException {
        if (enabledDb) {
            textFileRepository.deleteById(id);
        }
        else {
            List<FileData> allData = readAllData(false);
            List<FileData> dataList = new ArrayList<>();
            boolean found = false;

            for (FileData data : allData) {
                if (!data.getId().equals(id)) {
                    dataList.add(data);
                } else {
                    found = true;
                }
            }

            if (!found) {
                throw new IOException("ID not found for deletion");
            }
            writeDataListToFile(dataList);
        }
    }

    @Override
    public void deleteAllData(Boolean enabledDb) throws IOException {
        if (enabledDb) {
            textFileRepository.deleteAll();
        }
        else {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(getFile()))) {
                writer.write("");
            } catch (IOException e) {
                System.err.println("Error clearing data from file: " + e.getMessage());
                throw e;
            }
        }
    }

    @Override
    public void mergeData(String id1, String id2, Boolean enabledDb) throws IOException {
        List<FileData> allData = readAllData(enabledDb);
        FileData data1 = null;
        FileData data2 = null;

        for (FileData data : allData) {
            if (data.getId().equals(id1)) {
                data1 = data;
            } else if (data.getId().equals(id2)) {
                data2 = data;
            }
        }

        if (data1 == null || data2 == null) {
            throw new IOException("One or both IDs not found.");
        }
        String mergedContent = data1.getContent() + " " + data2.getContent();
        deleteSpecificData(id1, enabledDb);
        deleteSpecificData(id2, enabledDb);

        FileData mergedData = new FileData();
        mergedData.setId(id1);  // Or generate a new ID
        mergedData.setContent(mergedContent);
        insertData(mergedData, enabledDb);
    }

    @Override
    public void sortData(String sortBy, Boolean enabledDb) throws IOException {
        List<FileData> allData = readAllData(enabledDb);
        // Sort data based on the sortBy parameter
        if (sortBy == null || sortBy.equals("id")) {
            allData.sort(Comparator.comparing(FileData::getId));
        } else if (sortBy.equals("content")) {
            allData.sort(Comparator.comparing(FileData::getContent));
        } else {
            throw new IllegalArgumentException("Invalid sort criterion: " + sortBy);
        }

        writeDataListToFile(allData);
    }

    @Override
    public List<FileData> searchData(String content, Boolean enabledDb) throws IOException {
        List<FileData> allData = readAllData(enabledDb);
        List<FileData> result = new ArrayList<>();

        for (FileData data : allData) {
            if (data.getContent() != null && data.getContent().equals(content)) {
                result.add(data);
            }
        }

        return result;
    }

    @Override
    public void writeDataListToFile(List<FileData> dataList) throws IOException {
        if (dataList == null) {
            throw new IllegalArgumentException("Data list cannot be null");
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(getFile()))) {
            for (FileData data : dataList) {
                if (data.getId() == null || data.getId().trim().isEmpty()) {
                    throw new IllegalArgumentException("FileData ID cannot be null or empty");
                }
                if (data.getContent() == null) {
                    throw new IllegalArgumentException("FileData content cannot be null");
                }
                writer.write(data.getId() + "," + data.getContent());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error writing data list to file: " + e.getMessage());
            throw e;
        }
    }
}



