package com.example.text_writer_intel.repository;

import com.example.text_writer_intel.model.FileData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TextFileRepository extends JpaRepository<FileData, String> {
}
